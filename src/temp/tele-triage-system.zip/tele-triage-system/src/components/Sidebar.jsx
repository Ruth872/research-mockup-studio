import { 
  LayoutDashboard, 
  ClipboardCheck, 
  BarChart3, 
  Share2, 
  Users, 
  Settings,
  Activity,
  ChevronUp // Adding a small detail for the profile selector
} from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Sidebar = () => {
  const location = useLocation();

  // Helper to determine if a route is active
  const isActive = (path) => location.pathname === path;

  const navItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/triage', icon: ClipboardCheck, label: 'Triage' },
    { path: '/analytics', icon: BarChart3, label: 'Analytics' },
    { path: '/referrals', icon: Share2, label: 'Referrals' },
    { path: '/patients', icon: Users, label: 'Patients' },
  ];

  return (
    <aside className="aside-sidebar">
      {/* Brand Header */}
      <div className="brand-container">
        <div className="brand-icon-bg">
          <Activity size={20} color="white" />
        </div>
        <div className="brand-text">
          <div className="heading-1">Tele Triage System</div>
          <div className="sub-text">Clinic Admin Portal</div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="nav-menu">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`nav-link ${isActive(item.path) ? 'active' : ''}`}
          >
            <item.icon size={18} />
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>

      {/* Footer / User Profile */}
      <div className="sidebar-footer">
        <Link 
          to="/settings" 
          className={`nav-link ${isActive('/settings') ? 'active' : ''}`}
        >
          <Settings size={18} />
          <span>Settings</span>
        </Link>
        
        <div className="user-profile-card">
          <div className="user-avatar">
            <img 
              src="https://ui-avatars.com/api/?name=Sarah+Chen&background=CBD5E1&color=475569" 
              alt="Dr. Sarah Chen" 
            />
          </div>
          <div className="user-info">
            <div className="user-name">Dr. Sarah Chen</div>
            <div className="user-clinic">Central Clinic</div>
          </div>
          <ChevronUp size={14} className="profile-arrow" />
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;