import React, { useState } from 'react';
import axios from 'axios';
import { 
  User, Fingerprint, Phone, HeartPulse, ShieldAlert, 
  Pill, Activity, Users, Calendar, Mail, MapPin, 
  ChevronRight, CheckCircle2 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { API_BASE_URL } from '../components/config/config';
import '../css/Auth.css';

const PatientSignup = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    national_id: '', first_name: '', last_name: '', date_of_birth: '',
    gender: 'Male', phone_number: '', email: '', address: '',
    next_of_kin_name: '', next_of_kin_contact: '', blood_group: '',
    allergies: '', chronic_conditions: '', current_medications: ''
  });

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${API_BASE_URL}/patient_signup.php`, formData);
      console.log(res.data)
      if(res.data.success) {
        if(res.data.user_role == "patient"){
          localStorage.clear();
          // localStorage.setItem("user", res.data.user);
          // localStorage.setItem("role", res.data.user_role);
          navigate("/patient/login");
          return;
        }
      };
    } catch (err) {
      // alert("Error submitting registration.");
      console.log("error", err)
    }
  };

  return (
    <div className="medical-auth-container">
      <div className="medical-auth-card">
        {/* Header Section */}
        <header className="auth-header">
          <div className="brand-badge">
            <Activity size={20} />
            <span>MediFlow Health</span>
          </div>
          <h1>Patient Registration</h1>
          <p>Complete your clinical profile to help our team provide the best care.</p>
        </header>

        <form className="medical-form" onSubmit={handleSubmit}>
          
          {/* Section: Identity */}
          <div className="form-section">
            <h3 className="section-title"><User size={18} /> Personal Information</h3>
            <div className="input-grid">
              <div className="input-field">
                <label>First Name</label>
                <input type="text" name="first_name" required onChange={handleChange} placeholder="John" />
              </div>
              <div className="input-field">
                <label>Last Name</label>
                <input type="text" name="last_name" required onChange={handleChange} placeholder="Doe" />
              </div>
              <div className="input-field">
                <label>NRC / National ID</label>
                <div className="icon-input">
                  <Fingerprint size={16} />
                  <input type="text" name="national_id" required onChange={handleChange} placeholder="000000/00/1" />
                </div>
              </div>
              <div className="input-field">
                <label>Date of Birth</label>
                <div className="icon-input">
                  <Calendar size={16} />
                  <input type="date" name="date_of_birth" required onChange={handleChange} />
                </div>
              </div>
              <div className="input-field">
                <label>Gender</label>
                <select name="gender" onChange={handleChange}>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="input-field">
                <label>Phone Number</label>
                <div className="icon-input">
                  <Phone size={16} />
                  <input type="text" name="phone_number" required onChange={handleChange} placeholder="+260" />
                </div>
              </div>
            </div>
          </div>

          {/* Section: Clinical History */}
          <div className="form-section highlight">
            <h3 className="section-title"><HeartPulse size={18} /> Clinical Background</h3>
            <div className="input-grid">
              <div className="input-field">
                <label>Blood Group</label>
                <select name="blood_group" onChange={handleChange}>
                  <option value="">Select Group</option>
                  <option value="A+">A+</option><option value="O+">O+</option>
                  <option value="B+">B+</option><option value="AB+">AB+</option>
                  <option value="A-">A-</option><option value="O-">O-</option>
                </select>
              </div>
              <div className="input-field">
                <label>Known Allergies</label>
                <div className="icon-input">
                  <ShieldAlert size={16} />
                  <input type="text" name="allergies" onChange={handleChange} placeholder="e.g. Peanuts, Penicillin" />
                </div>
              </div>
              <div className="input-field full-span">
                <label>Chronic Conditions</label>
                <div className="icon-input">
                  <Activity size={16} />
                  <input type="text" name="chronic_conditions" onChange={handleChange} placeholder="e.g. Asthma, Diabetes" />
                </div>
              </div>
              <div className="input-field full-span">
                <label>Current Medications</label>
                <div className="icon-input">
                  <Pill size={16} />
                  <textarea name="current_medications" onChange={handleChange} placeholder="List medications and dosage..." rows="3" />
                </div>
              </div>
            </div>
          </div>

          {/* Section: Emergency */}
          <div className="form-section">
            <h3 className="section-title"><Users size={18} /> Emergency Contact</h3>
            <div className="input-grid">
              <div className="input-field">
                <label>Next of Kin Name</label>
                <input type="text" name="next_of_kin_name" onChange={handleChange} placeholder="Full Name" />
              </div>
              <div className="input-field">
                <label>Emergency Phone</label>
                <input type="text" name="next_of_kin_contact" onChange={handleChange} placeholder="+260" />
              </div>
            </div>
          </div>

          <button type="submit" className="submit-registration">
            Complete Registration <ChevronRight size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};

export default PatientSignup;