import React from 'react';
import { 
  Search, Bell, Settings, User, MapPin, Phone, 
  Droplet, Heart, Clock, ShieldAlert, Plus, 
  MessageSquare, ChevronRight, Activity, Calendar
} from 'lucide-react';
import '../css/Patient.css';

const Patient = () => {
  const sessions = [
    {
      id: "SESSION #1204",
      date: "October 24, 2023 • 14:30",
      urgency: "Moderate",
      symptoms: ["Persistent Cough", "Mild Fever (38.2°C)", "Shortness of breath"],
      description: "Patient reports feeling weak for the last 3 days with escalating chest tightness.",
      advice: [
        "Schedule an in-person respiratory assessment within 24 hours.",
        "Monitor oxygen levels; seek ER if it drops below 92%.",
        "Increase fluid intake and rest."
      ]
    },
    {
      id: "SESSION #1182",
      date: "September 12, 2023 • 09:15",
      urgency: "Low",
      symptoms: ["Joint Pain (Right Knee)", "Mild Swelling"],
      description: "Pain follows physical activity, describes it as a dull ache.",
      advice: [
        "Apply RICE protocol (Rest, Ice, Compression, Elevation).",
        "Use OTC anti-inflammatories as needed."
      ]
    }
  ];

  return (
    <div className="patient-portal-container">
      {/* Header - Top Navigation */}
      <header className="top-nav">
        <div className="nav-left">
          <div className="logo-container">
            <div className="logo-icon-bg">
              <Activity size={20} color="#0059B2" />
            </div>
            <h2 className="brand-name">Tele-Triage Portal</h2>
          </div>
          <nav className="nav-links">
            <span className="link">Dashboard</span>
            <span className="link active">Patients</span>
            <span className="link">Reports</span>
          </nav>
        </div>

        <div className="nav-right">
          <div className="search-bar">
            <Search size={15} color="#64748B" />
            <input type="text" placeholder="Search records..." />
          </div>
          <button className="nav-icon-btn"><Bell size={20} /></button>
          <button className="nav-icon-btn"><Settings size={20} /></button>
          <div className="user-avatar-small"></div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="main-layout">
        
        {/* Sidebar: Patient Demographics */}
        <aside className="patient-sidebar">
          <div className="profile-card">
            <div className="avatar-border">
              <div className="avatar-main"></div>
            </div>
            <h1 className="patient-title">John Doe, 34</h1>
            <p className="patient-id">Patient ID: #88291-KAB</p>

            <div className="info-list">
              <div className="info-item">
                <MapPin size={16} color="#0059B2" />
                <div>
                  <label>LOCATION</label>
                  <p>Kabwata, Lusaka, Zambia</p>
                </div>
              </div>
              <div className="info-item">
                <Phone size={18} color="#0059B2" />
                <div>
                  <label>CONTACT</label>
                  <p>+260 977 123456</p>
                </div>
              </div>
              <div className="info-item">
                <Droplet size={16} color="#0059B2" />
                <div>
                  <label>BLOOD TYPE</label>
                  <p>O Positive (O+)</p>
                </div>
              </div>
            </div>
          </div>

          <div className="emergency-card">
            <div className="card-header">
              <ShieldAlert size={10} color="#0059B2" />
              <h3>Emergency Contact</h3>
            </div>
            <div className="contact-box">
              <p className="contact-name">Jane Doe</p>
              <p className="contact-relation">Spouse • +260 978 654321</p>
            </div>
          </div>

          <nav className="sidebar-nav">
            <button className="nav-btn active">
              <Clock size={18} /> Triage History
            </button>
            <button className="nav-btn">
              <Activity size={20} /> Medical History
            </button>
            <button className="nav-btn">
              <Plus size={14} /> Lab Results
            </button>
          </nav>
        </aside>

        {/* Triage Timeline Area */}
        <section className="timeline-area">
          <div className="timeline-header">
            <div>
              <h2>Tele-Triage History</h2>
              <p>Chronological list of AI-assisted triage sessions</p>
            </div>
            <button className="btn-new-session">
              <Plus size={12} /> New Session
            </button>
          </div>

          <div className="timeline-thread">
            {sessions.map((session, idx) => (
              <div key={idx} className="session-card">
                <div className="timeline-dot"></div>
                <div className="card-content">
                  <div className="card-top">
                    <div>
                      <span className="session-tag">{session.id}</span>
                      <h3 className="session-date">{session.date}</h3>
                    </div>
                    <span className={`urgency-badge ${session.urgency.toLowerCase()}`}>
                      Urgency: {session.urgency}
                    </span>
                  </div>

                  <div className="card-body">
                    <div className="body-left">
                      <div className="section-title">
                        <User size={16} color="#0059B2" />
                        <span>Reported Symptoms</span>
                      </div>
                      <div className="symptom-tags">
                        {session.symptoms.map((s, i) => (
                          <span key={i} className="tag">{s}</span>
                        ))}
                      </div>
                      <p className="session-desc">"{session.description}"</p>
                    </div>

                    <div className="body-right">
                      <div className="section-title">
                        <Activity size={16} color="#0059B2" />
                        <span>AI Clinical Advice</span>
                      </div>
                      <ul className="advice-list">
                        {session.advice.map((a, i) => (
                          <li key={i}>{a}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
};

export default Patient;