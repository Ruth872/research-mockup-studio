import React, { useState } from 'react';
import axios from 'axios';
import { 
  Fingerprint, Phone, Activity, ChevronRight, Lock, UserCircle 
} from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { API_BASE_URL } from '../components/config/config';
import '../css/Auth.css';

const PatientLogin = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState({
    national_id: '',
    phone_number: ''
  });

  const handleChange = (e) => setCredentials({ ...credentials, [e.target.name]: e.target.value });

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await axios.post(`${API_BASE_URL}/patient_login.php`, credentials);
      if (res.data.success) {
        localStorage.clear();
        localStorage.setItem("user", JSON.stringify(res.data.user));
        localStorage.setItem("role", res.data.user_role);
        navigate("/chat");
      } else {
        alert(res.data.message);
      }
    } catch (err) {
      console.error("Login Error:", err);
      alert("System connection error. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="medical-auth-container">
      <div className="medical-auth-card login-card">
        <header className="auth-header">
          <div className="brand-badge">
            <Activity size={20} />
            <span>MediFlow Health</span>
          </div>
          <h1>Patient Portal</h1>
          <p>Access your triage history and AI clinical advice using your registered credentials.</p>
        </header>

        <form className="medical-form" onSubmit={handleLogin}>
          <div className="form-section">
            <div className="input-field">
              <label>NRC / National ID</label>
              <div className="icon-input">
                <Fingerprint size={18} />
                <input 
                  type="text" 
                  name="national_id" 
                  required 
                  onChange={handleChange} 
                  placeholder="000000/00/1" 
                />
              </div>
            </div>

            <div className="input-field">
              <label>Registered Phone Number</label>
              <div className="icon-input">
                <Phone size={18} />
                <input 
                  type="text" 
                  name="phone_number" 
                  required 
                  onChange={handleChange} 
                  placeholder="+260..." 
                />
              </div>
            </div>
          </div>

          <button type="submit" className="submit-registration" disabled={loading}>
            {loading ? "Verifying..." : "Access Portal"} <ChevronRight size={18} />
          </button>

          <div className="auth-footer">
            <p>First time visiting? <Link to="/signup">Create your medical profile</Link></p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PatientLogin;