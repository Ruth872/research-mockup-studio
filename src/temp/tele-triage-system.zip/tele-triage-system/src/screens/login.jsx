import React, { useState } from 'react';
import axios from 'axios';
import { Mail, Lock, LogIn, Stethoscope, HelpCircle } from 'lucide-react';
import '../css/Auth.css'; 
import { API_BASE_URL } from '../components/config/config';
import { useNavigate } from 'react-router-dom';
const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [status, setStatus] = useState({ type: '', message: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ type: 'loading', message: 'Authenticating...' });

    try {
      const response = await axios.post(`${API_BASE_URL}/login.php` , formData);
      console.log(response.data)
      if (response.data.success) {
        setStatus({ type: 'success', message: 'Login successful! Redirecting...' });
        localStorage.setItem('user', JSON.stringify(response.data.user));
        const user_role = response.data.user.role;
        // console.log(user_role)
        if(user_role){
          if(user_role == "Doctor"){
            navigate("/");
          }

          if(user_role == "patient"){
            // navigate("/");
            console.log("patient screen")
          }
        }else{
          setStatus({ type: 'error', message: "user does not exist" });
        }
      } else {
        setStatus({ type: 'error', message: response.data.message });
      }
    } catch (error) {
      setStatus({ type: 'error', message: 'Connection to medical server failed.' });
    }
  };

  return (
    <div className="auth-wrapper">
      <header className="brand-header-top">
        <div className="brand-icon-bg"><Stethoscope size={18} color="#0059B2" /></div>
        <div>
          <h2 className="brand-title">Kabwata Clinic</h2>
          <p className="brand-sub">Tele-Triage Portal</p>
        </div>
      </header>

      <div className="auth-card">
        <div className="icon-lock-bg"><LogIn size={24} color="#0059B2" /></div>
        <h1>Login to Portal</h1>
        <p className="sub-description">Enter your clinic credentials to access the tele-triage dashboard.</p>

        {status.message && (
          <div className={`alert-box ${status.type}`}>{status.message}</div>
        )}

        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Email Address</label>
            <div className="input-with-icon">
              <Mail size={16} className="input-icon" />
              <input 
                type="email" 
                name="email"
                required
                placeholder="dr.chen@kabwataclinic.zm" 
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="input-group">
            <div className="label-row">
              <label>Password</label>
              <a href="/forgot-password" className="text-link small">Forgot?</a>
            </div>
            <div className="input-with-icon">
              <Lock size={16} className="input-icon" />
              <input 
                type="password" 
                name="password"
                required
                placeholder="••••••••••••" 
                onChange={handleChange}
              />
            </div>
          </div>

          <button type="submit" className="btn-primary" disabled={status.type === 'loading'}>
            {status.type === 'loading' ? 'Verifying...' : 'Login'} <LogIn size={16} />
          </button>
        </form>

        <div className="footer-links">
          <span>Need an account? <a href="/signup" className="text-link">Sign Up</a></span>
        </div>
      </div>
      
      <button className="floating-help"><HelpCircle size={20} /></button>
      <footer className="portal-footer">© 2024 Kabwata Clinic Tele-Triage System. All rights reserved.</footer>
    </div>
  );
};

export default Login;