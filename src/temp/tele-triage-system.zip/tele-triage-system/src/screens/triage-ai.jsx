import React, { useState, useRef, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { 
  LayoutDashboard, ClipboardCheck, BarChart3, Share2, Users, 
  Activity, Plus, Send, Zap 
} from 'lucide-react';
import { API_BASE_URL } from '../components/config/config';
import '../css/MedicalChat.css';
import Sidebar from '../components/Sidebar';

const AIInterface = () => {
  const [input, setInput] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [messages, setMessages] = useState([
    { id: 1, role: 'assistant', content: 'Hi! How can I assist you with your health or triage today? 😊' }
  ]);
  
  const scrollRef = useRef(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    // 1. Get Patient Data safely from localStorage
    const storedUser = localStorage.getItem("user");
    let patientId = null;
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        patientId = parsedUser.id;
      } catch (e) { console.error("User data parse error", e); }
    }

    // 2. Add User Message to UI
    const userMsg = { id: Date.now(), role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    const currentInput = input; // Capture input before clearing
    setInput('');

    // 3. Add temporary "Thinking" state
    const botTempId = Date.now() + 1;
    setMessages(prev => [...prev, { 
      id: botTempId, 
      role: 'assistant', 
      content: 'Connecting to clinical AI...', 
      isTyping: true 
    }]);

    try {
      // 4. Actual Backend Call
      const res = await axios.post(`${API_BASE_URL}/chat_handler.php`, {
        message: currentInput,
        patient_id: patientId
      });

      if (res.data.success) {
        // Replace "Thinking" with real response
        setMessages(prev => prev.map(msg => 
          msg.id === botTempId 
            ? { id: botTempId, role: 'assistant', content: res.data.content } 
            : msg
        ));
      } else {
        throw new Error(res.data.message);
      }
    } catch (err) {
      console.error("Chat Error:", err);
      setMessages(prev => prev.map(msg => 
        msg.id === botTempId 
          ? { id: botTempId, role: 'assistant', content: "I'm having trouble reaching the clinic server. Please try again." } 
          : msg
      ));
    }
  };

  return (
    <div className="app-shell">
      <Sidebar />
      <main className="app-main">
        <header className="main-header">
          <div className="header-left">
            <button className="model-selector">
              <div className="model-dot"><Zap size={10} /></div>
              Tele Triage AI 
            </button>
          </div>
          <div className="header-right">
            <button className="new-chat-btn desktop-only" onClick={() => setMessages([{ id: 1, role: 'assistant', content: 'New session started. How can I help?' }])}>
              <Plus size={14} /> New Chat
            </button>
            <div className="user-nav-wrapper">
               <Activity size={18} color="#3b82f6" />
            </div>
          </div>
        </header>

        <div className="chat-viewport" ref={scrollRef}>
          <div className="chat-max-width">
            {messages.map((msg) => (
              <div key={msg.id} className={`message-row ${msg.role}`}>
                {msg.role === 'assistant' && (
                  <div className="bot-avatar">
                    <Zap size={14} color="white" />
                  </div>
                )}
                <div className={`text-bubble ${msg.role} ${msg.isTyping ? 'typing-glow' : ''}`}>
                  {msg.content}
                </div>
              </div>
            ))}
          </div>
        </div>

        <footer className="input-bar-container">
          <div className="input-wrapper">
            <input 
              placeholder="Describe your symptoms..." 
              value={input} 
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <button className="send-action-btn" onClick={handleSend} disabled={!input.trim()}>
              <Send size={18} />
            </button>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default AIInterface;