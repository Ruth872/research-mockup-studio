import React, { useState } from 'react';
import axios from 'axios';
import { Mail, Lock, UserPlus, Stethoscope, User, BriefcaseMedical, Building2, Phone } from 'lucide-react';
import '../css/Auth.css'; 
import { API_BASE_URL } from '../components/config/config';
import { useNavigate } from 'react-router-dom';


const Signup = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    role: 'Doctor',
    specialization: '',
    license_number: '',
    phone_number: '',
    email: '',
    password: ''
  });


  const [message, setMessage] = useState({ type: '', text: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage({ type: 'info', text: 'Processing request...' });

    try {
      const response = await axios.post(`${API_BASE_URL}/signup.php`, formData);
      if (response.data.success) {
        setMessage({ type: 'success', text: 'Account created! Redirecting to login...' });
        navigate("/admin/login");
      } else {
        setMessage({ type: 'error', text: response.data.message });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Server connection failed.' });
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card signup-large">
        <div className="icon-lock-bg"><UserPlus size={24} color="#0059B2" /></div>
        <h1>Request Portal Access</h1>
        <p className="sub-description">Provide your clinical credentials to join the Kabwata Clinic network.</p>

        {message.text && <div className={`alert ${message.type}`}>{message.text}</div>}

        <form className="auth-form grid-2" onSubmit={handleSubmit}>
          <div className="input-group">
            <label>First Name</label>
            <div className="input-with-icon">
              <User size={16} className="input-icon" />
              <input type="text" name="first_name" required onChange={handleChange} placeholder="Sarah" />
            </div>
          </div>

          <div className="input-group">
            <label>Last Name</label>
            <div className="input-with-icon">
              <User size={16} className="input-icon" />
              <input type="text" name="last_name" required onChange={handleChange} placeholder="Mwila" />
            </div>
          </div>

          <div className="input-group">
            <label>Role</label>
            <div className="input-with-icon">
              <Stethoscope size={16} className="input-icon" />
              <select name="role" onChange={handleChange}>
                <option value="Doctor">Doctor</option>
                <option value="Clinical Officer">Clinical Officer</option>
                <option value="Nurse">Nurse</option>
                <option value="Admin">Admin</option>
              </select>
            </div>
          </div>

          <div className="input-group">
            <label>License Number</label>
            <div className="input-with-icon">
              <BriefcaseMedical size={16} className="input-icon" />
              <input type="text" name="license_number" required onChange={handleChange} placeholder="HPCZ/12345" />
            </div>
          </div>

          <div className="input-group">
            <label>Phone Number</label>
            <div className="input-with-icon">
              <Phone size={16} className="input-icon" />
              <input type="text" name="phone_number" required onChange={handleChange} placeholder="+260..." />
            </div>
          </div>

          <div className="input-group">
            <label>Email Address</label>
            <div className="input-with-icon">
              <Mail size={16} className="input-icon" />
              <input type="email" name="email" required onChange={handleChange} placeholder="s.mwila@kabwataclinic.zm" />
            </div>
          </div>

          <div className="input-group full-width">
            <label>Password</label>
            <div className="input-with-icon">
              <Lock size={16} className="input-icon" />
              <input type="password" name="password" required onChange={handleChange} placeholder="••••••••" />
            </div>
          </div>

          <button type="submit" className="btn-primary full-width">Submit Request</button>
        </form>
      </div>
    </div>
  );
};

export default Signup;