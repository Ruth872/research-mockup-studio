import React from 'react';
import { 
  Search, Bell, HelpCircle, Activity, CheckCircle2, 
  ChevronDown, Eye, Share2, FileText, Plus, Clock 
} from 'lucide-react';
import '../css/TriagePage.css';
import Sidebar from '../components/Sidebar';

const TriagePage = () => {
  const triageData = [
    { id: '#KT-9021', name: 'Elias Mulenga', urgency: 'High Priority', symptom: 'Severe Chest Pain, Dyspnea', recommendation: 'Immediate ECG & Vitals', status: 'Pending' },
    { id: '#KT-8834', name: 'Chanda Kapambwe', urgency: 'Medium', symptom: 'Abdominal cramps, Fever', recommendation: 'General Physician Consult', status: 'Reviewed' },
    { id: '#KT-9104', name: 'Bwalya Mutale', urgency: 'Routine', symptom: 'Seasonal allergy, Skin rash', recommendation: 'Pharmacy / Nurse Lead', status: 'Follow-up' },
    { id: '#KT-7752', name: 'Natasha Zulu', urgency: 'High Priority', symptom: 'Persistent high fever, Seizure', recommendation: 'Emergency Stabilization', status: 'Pending' },
    { id: '#KT-8901', name: 'Kelvin Phiri', urgency: 'Medium', symptom: 'Migraine, Photophobia', recommendation: 'Neurology Referral', status: 'Reviewed' }
  ];

  return (
    <div className="admin-container">
      <Sidebar />
      
      <main className="main-content">
        {/* Top Search Bar */}
        <header className="header-top-nav">
          <div className="search-container">
            <Search size={18} className="search-icon" />
            <input type="text" placeholder="Search patients, symptoms, or IDs..." />
          </div>
          <div className="header-actions">
            <div className="icon-badge-container">
              <Bell size={20} />
              <span className="dot-notification"></span>
            </div>
            <HelpCircle size={20} className="help-icon" />
          </div>
        </header>

        <div className="dashboard-scroll-area">
          {/* Header Section */}
          <section className="content-header">
            <div className="header-text">
              <h1 className="main-heading">Triage Submissions</h1>
              <p className="sub-heading">Real-time patient intake and AI-assisted priority routing.</p>
            </div>
            <div className="header-btns">
              <button className="btn-secondary"><Share2 size={16} /> Export CSV</button>
              <button className="btn-primary"><Plus size={16} /> Manual Entry</button>
            </div>
          </section>

          {/* Stats Grid */}
          <section className="stats-grid">
            <div className="stat-card">
              <div className="stat-header">
                <div className="stat-icon-box blue"><Clock size={20} /></div>
                <span className="trend-pill positive">+5.2%</span>
              </div>
              <label>Pending Reviews</label>
              <div className="stat-value">12</div>
              <p className="stat-footer">vs. 8 yesterday</p>
            </div>

            <div className="stat-card">
              <div className="stat-header">
                <div className="stat-icon-box red"><Activity size={20} /></div>
                <span className="trend-pill negative">-2.4%</span>
              </div>
              <label>Urgent Cases</label>
              <div className="stat-value text-red">05</div>
              <p className="stat-footer">High priority focus</p>
            </div>

            <div className="stat-card">
              <div className="stat-header">
                <div className="stat-icon-box green"><CheckCircle2 size={20} /></div>
                <span className="trend-pill positive">+0.8%</span>
              </div>
              <label>Total Today</label>
              <div className="stat-value">48</div>
              <p className="stat-footer">Based on current shift</p>
            </div>
          </section>

          <section className="table-wrapper">
            <div className="table-filters">
              <div className="filter-group">
                <div className="filter-pill">Urgency: <strong>All Levels</strong> <ChevronDown size={14} /></div>
                <div className="filter-pill">Date: <strong>Today</strong> <ChevronDown size={14} /></div>
              </div>
              <button className="text-link">Clear all</button>
            </div>

            <table className="triage-table">
              <thead>
                <tr>
                  <th>PATIENT NAME</th>
                  <th>URGENCY</th>
                  <th>PRIMARY SYMPTOM</th>
                  <th>AI RECOMMENDATION</th>
                  <th>STATUS</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {triageData.map((patient, index) => (
                  <tr key={index}>
                    <td>
                      <div className="patient-info">
                        <div className="avatar">{patient.name.charAt(0)}</div>
                        <div>
                          <p className="name">{patient.name}</p>
                          <p className="id">{patient.id}</p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className={`urgency-tag ${patient.urgency.toLowerCase().split(' ')[0]}`}>
                        {patient.urgency}
                      </span>
                    </td>
                    <td className="symptom-cell">{patient.symptom}</td>
                    <td>
                      <div className="ai-badge">
                        <Activity size={14} /> {patient.recommendation}
                      </div>
                    </td>
                    <td>
                      <div className="status-indicator">
                        <span className={`dot ${patient.status.toLowerCase().replace('-', '')}`}></span>
                        {patient.status}
                      </div>
                    </td>
                    <td className="text-right">
                      <button className="icon-btn"><Eye size={18} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </div>
      </main>
    </div>
  );
};

export default TriagePage;