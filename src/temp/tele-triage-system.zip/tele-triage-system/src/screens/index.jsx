import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { 
  LayoutDashboard, ClipboardList, BarChart3, Share2, Users, 
  Settings, Calendar, Download, MoreVertical, Search, Clock, Smile, Activity 
} from 'lucide-react';
import Sidebar from '../components/Sidebar';
const data = [
  { name: 'MON', patients: 300 },
  { name: 'TUE', patients: 350 },
  { name: 'WED', patients: 520 },
  { name: 'THU', patients: 400 },
  { name: 'FRI', patients: 550 },
  { name: 'SAT', patients: 600 },
  { name: 'SUN', patients: 620 },
];

const AdminDashboard = () => {
  return (
    <div className="app-container">
      <Sidebar />
      {/* Main Content */}
      <main className="main-content">
        <header className="main-header">
          <div className="header-titles">
            <h2>Patient Flow Analytics</h2>
            <p>Real-time overview of clinic attendance and operational efficiency.</p>
          </div>
          <div className="header-actions">
            <button className="btn-white">
              <Calendar size={18} /> Last 30 Days
            </button>
            <button className="btn-blue">
              <Download size={14} /> Export Report
            </button>
          </div>
        </header>

        {/* Stats Grid */}
        <section className="stats-grid">
          <StatCard icon={<ClipboardList size={20} />} label="Total Triage Sessions" value="1,284" change="+12.5%" sub="vs. 1,141 last month" color="#0059B2" />
          <StatCard icon={<Share2 size={20} />} label="Active Referrals" value="156" change="+5.2%" sub="12 pending approval" color="#F59E0B" />
          <StatCard icon={<Clock size={20} />} label="Avg. Wait Time" value="18" unit="min" change="-2.4%" sub="Target: 15 min" color="#6366F1" isNegative />
          <StatCard icon={<Smile size={20} />} label="Patient Satisfaction" value="4.9" unit="/5" change="+0.8%" sub="Based on 842 reviews" color="#10B981" />
        </section>

        {/* Charts Section */}
        <section className="charts-row">
          <div className="chart-card attendance-trend">
            <div className="card-header">
              <h3>Weekly Attendance Trends</h3>
              <div className="chart-legend">
                <span className="dot current"></span> Current <span className="dot target"></span> Target
              </div>
            </div>
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={data}>
                  <defs>
                    <linearGradient id="colorPatients" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0059B2" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#0059B2" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94A3B8', fontSize: 12}} dy={10} />
                  <YAxis hide />
                  <Tooltip />
                  <Area type="monotone" dataKey="patients" stroke="#0059B2" strokeWidth={3} fillOpacity={1} fill="url(#colorPatients)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="chart-card peak-hours">
            <h3>Peak Consultation Hours</h3>
            <div className="heatmap-container">
              <HeatMapRow range="08:00 - 10:00" label="Light" percent={30} color="#CBD5E1" />
              <HeatMapRow range="10:00 - 12:00" label="High" percent={80} color="#F59E0B" />
              <HeatMapRow range="12:00 - 14:00" label="Moderate" percent={60} color="#0059B2" />
              <HeatMapRow range="14:00 - 16:00" label="Critical Peak" percent={100} color="#E11D48" />
              <HeatMapRow range="16:00 - 18:00" label="Moderate" percent={50} color="#0059B2" />
            </div>
            <div className="recommendation-box">
              <p className="rec-title">RECOMMENDATION</p>
              <p>Staffing should be increased by 25% during the 14:00 peak.</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

const StatCard = ({ icon, label, value, unit, change, sub, color, isNegative }) => (
  <div className="stat-card">
    <div className="stat-card-top">
      <div className="stat-icon-wrap" style={{ backgroundColor: `${color}1A`, color: color }}>{icon}</div>
      <div className={`stat-badge ${isNegative ? 'red' : 'green'}`}>{change}</div>
    </div>
    <div className="stat-card-label">{label}</div>
    <div className="stat-card-value">{value} <span>{unit}</span></div>
    <div className="stat-card-sub">{sub}</div>
  </div>
);

const HeatMapRow = ({ range, label, percent, color }) => (
  <div className="heatmap-row">
    <div className="heatmap-info">
      <span>{range}</span>
      <span style={{ color }}>{label}</span>
    </div>
    <div className="heatmap-bar-bg">
      <div className="heatmap-bar-fill" style={{ width: `${percent}%`, backgroundColor: color }}></div>
    </div>
  </div>
);

export default AdminDashboard;