import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AdminDashboard from './screens';
import Sidebar from './components/Sidebar';
import './App.css';
import MedicalChat from './screens/triage-ai';
import TriagePage from './screens/TriagePage';
import Patient from './screens/Patient';
import Login from './screens/login';
import Signup from './screens/signup';
import PatientSignup from './screens/PatientSignup';
import PatientLogin from './screens/PatientLogin';
function App() {
  return (
    <Router>
      <div className="">
        <main className="">
          <Routes>
            <Route path="/" element={<AdminDashboard />} />
            <Route path="/chat" element={<MedicalChat />} />
            <Route path="/admin/triage" element={<TriagePage />} />
            <Route path="/admin/patient" element={<Patient />} />
            <Route path="/admin/signup" element={<Signup/>}/>
            <Route path="/admin/login" element={<Login/>}/>



            <Route path="/patient/signup" element={<PatientSignup />}/>
            <Route path="/patient/login" element={<PatientLogin />}/>

          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;