<?php
// signup.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Include the db_config.php you provided
require_once 'connection.php';

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

if (
    !empty($data['first_name']) &&
    !empty($data['last_name']) &&
    !empty($data['email']) &&
    !empty($data['password'])
) {
    try {
        // 1. Check if email already exists
        $checkEmail = $pdo->prepare("SELECT email FROM staff WHERE email = ?");
        $checkEmail->execute([$data['email']]);
        
        if ($checkEmail->rowCount() > 0) {
            echo json_encode(["success" => false, "message" => "Email already registered."]);
            exit;
        }

        // 2. Hash the password
        $password_hash = password_hash($data['password'], PASSWORD_BCRYPT);

        // 3. Insert into staff table
        $sql = "INSERT INTO staff (
                    first_name, 
                    last_name, 
                    role, 
                    specialization, 
                    license_number, 
                    phone_number, 
                    email, 
                    password_hash, 
                    availability_status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Offline')";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $data['first_name'],
            $data['last_name'],
            $data['role'],
            $data['specialization'] ?? null,
            $data['license_number'] ?? null,
            $data['phone_number'],
            $data['email'],
            $password_hash
        ]);

        echo json_encode(["success" => true, "message" => "Account created successfully."]);

    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Database error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Incomplete form data."]);
}
?>