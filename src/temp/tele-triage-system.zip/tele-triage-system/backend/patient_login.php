<?php
// patient_login.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['national_id']) || empty($data['phone_number'])) {
    echo json_encode(["success" => false, "message" => "Please provide both ID and Phone Number."]);
    exit;
}

try {
    // Check if patient exists with matching NRC and Phone
    $stmt = $pdo->prepare("SELECT patient_id, first_name, last_name, phone_number, blood_group FROM patients WHERE national_id = ? AND phone_number = ?");
    $stmt->execute([$data['national_id'], $data['phone_number']]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($patient) {
        echo json_encode([
            "success" => true,
            "message" => "Authentication successful.",
            "user_role" => "patient",
            "user" => [
                "id" => $patient['patient_id'],
                "name" => $patient['first_name'] . " " . $patient['last_name'],
                "phone" => $patient['phone_number'],
                "blood_group" => $patient['blood_group']
            ]
        ]);
    } else {
        echo json_encode([
            "success" => false, 
            "message" => "Invalid credentials. Please ensure your NRC and Phone match your registration."
        ]);
    }

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Database Error: " . $e->getMessage()]);
}
?>