CREATE TABLE patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    national_id VARCHAR(20) UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    address TEXT,
    next_of_kin_name VARCHAR(100),
    next_of_kin_contact VARCHAR(20),
    blood_group VARCHAR(5),
    allergies TEXT,
    chronic_conditions TEXT,
    current_medications TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role ENUM('Doctor', 'Clinical Officer', 'Nurse', 'Admin', 'IT Support') NOT NULL,
    specialization VARCHAR(100),
    license_number VARCHAR(50),
    phone_number VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    availability_status ENUM('Online', 'Offline') DEFAULT 'Offline',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE facilities (
    facility_id INT AUTO_INCREMENT PRIMARY KEY,
    facility_name VARCHAR(100) NOT NULL,
    location VARCHAR(150),
    contact_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE triage_records (
    triage_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    staff_id INT,
    facility_id INT,
    triage_mode ENUM('Web', 'Mobile App', 'SMS', 'Phone') NOT NULL,
    symptoms TEXT NOT NULL,
    symptom_duration VARCHAR(100),
    severity_level ENUM('Mild', 'Moderate', 'Severe', 'Critical') NOT NULL,
    triage_score INT,
    priority_level ENUM('Red', 'Orange', 'Yellow', 'Green'),
    recommended_action ENUM('Emergency Referral', 'Same-Day Visit', 'Routine Appointment', 'Home Care Advice'),
    status ENUM('Pending', 'Completed', 'Referred', 'Closed') DEFAULT 'Pending',
    triage_datetime DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id),
    FOREIGN KEY (facility_id) REFERENCES facilities(facility_id)
);


CREATE TABLE appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    staff_id INT NOT NULL,
    facility_id INT NOT NULL,
    appointment_date DATETIME NOT NULL,
    status ENUM('Scheduled', 'Completed', 'Cancelled') DEFAULT 'Scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id),
    FOREIGN KEY (facility_id) REFERENCES facilities(facility_id)
);


CREATE TABLE referrals (
    referral_id INT AUTO_INCREMENT PRIMARY KEY,
    triage_id INT NOT NULL,
    referred_facility_id INT NOT NULL,
    referral_reason TEXT,
    referral_status ENUM('Pending', 'Accepted', 'Rejected', 'Completed') DEFAULT 'Pending',
    referral_date DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (triage_id) REFERENCES triage_records(triage_id),
    FOREIGN KEY (referred_facility_id) REFERENCES facilities(facility_id)
);


CREATE TABLE patient_flow_analytics (
    flow_id INT AUTO_INCREMENT PRIMARY KEY,
    triage_id INT NOT NULL,
    checkin_time DATETIME,
    triage_time DATETIME,
    consultation_start DATETIME,
    consultation_end DATETIME,
    discharge_time DATETIME,
    total_waiting_time INT,  -- in minutes
    total_visit_duration INT, -- in minutes
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (triage_id) REFERENCES triage_records(triage_id)
);


CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    staff_id INT,
    message TEXT NOT NULL,
    notification_type ENUM('SMS', 'Email') NOT NULL,
    delivery_status ENUM('Sent', 'Failed', 'Pending') DEFAULT 'Pending',
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);


CREATE TABLE audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    user_role ENUM('Staff', 'Admin') NOT NULL,
    action_performed TEXT NOT NULL,
    ip_address VARCHAR(50),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE triage_algorithm_logs (
    algorithm_log_id INT AUTO_INCREMENT PRIMARY KEY,
    triage_id INT NOT NULL,
    algorithm_version VARCHAR(20),
    risk_score INT,
    confidence_level DECIMAL(5,2),
    processed_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (triage_id) REFERENCES triage_records(triage_id)
);




