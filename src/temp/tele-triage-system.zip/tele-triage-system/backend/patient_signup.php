<?php
// patient_signup.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$data = json_decode(file_get_contents("php://input"), true);

$required = ['national_id', 'first_name', 'last_name', 'date_of_birth', 'gender', 'phone_number'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        echo json_encode(["success" => false, "message" => "Please complete the required field: $field"]);
        exit;
    }
}

try {
    // Check for duplicate National ID
    $check = $pdo->prepare("SELECT patient_id FROM patients WHERE national_id = ?");
    $check->execute([$data['national_id']]);
    if ($check->rowCount() > 0) {
        echo json_encode(["success" => false, "message" => "This National ID is already registered."]);
        exit;
    }

    $sql = "INSERT INTO patients (
                national_id, first_name, last_name, date_of_birth, 
                gender, phone_number, email, address, 
                next_of_kin_name, next_of_kin_contact, blood_group, 
                allergies, chronic_conditions, current_medications
            ) VALUES (
                :nid, :fname, :lname, :dob, 
                :gender, :phone, :email, :address, 
                :nok_name, :nok_phone, :blood, 
                :allergies, :chronic, :meds
            )";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nid'        => $data['national_id'],
        ':fname'      => $data['first_name'],
        ':lname'      => $data['last_name'],
        ':dob'        => $data['date_of_birth'],
        ':gender'     => $data['gender'],
        ':phone'      => $data['phone_number'],
        ':email'      => $data['email'] ?? null,
        ':address'    => $data['address'] ?? null,
        ':nok_name'   => $data['next_of_kin_name'] ?? null,
        ':nok_phone'  => $data['next_of_kin_contact'] ?? null,
        ':blood'      => $data['blood_group'] ?? null,
        ':allergies'  => $data['allergies'] ?? null,
        ':chronic'    => $data['chronic_conditions'] ?? null,
        ':meds'       => $data['current_medications'] ?? null
    ]);

    echo json_encode([
        "success" => true, 
        "message" => "Patient registration successful! Welcome, " . $data['first_name'],
        "user_role" => "patient",
        "user" => json_encode([
            "phone" => $data['phone_number'],
        ])
    ]);

} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
}
?>