<?php
// login.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$data = json_decode(file_get_contents("php://input"), true);

if (!empty($data['email']) && !empty($data['password'])) {
    try {
        // 1. Fetch user by email
        $stmt = $pdo->prepare("SELECT * FROM staff WHERE email = ?");
        $stmt->execute([$data['email']]);
        $user = $stmt->fetch();

        if ($user && password_verify($data['password'], $user['password_hash'])) {
            
            // 2. Log the successful login in audit_logs
            $logStmt = $pdo->prepare("INSERT INTO audit_logs (user_id, user_role, action_performed, ip_address) VALUES (?, ?, ?, ?)");
            $logStmt->execute([
                $user['staff_id'],
                $user['role'],
                'User Logged In',
                $_SERVER['REMOTE_ADDR']
            ]);

            // 3. Update status to Online
            $updateStatus = $pdo->prepare("UPDATE staff SET availability_status = 'Online' WHERE staff_id = ?");
            $updateStatus->execute([$user['staff_id']]);

            // Return success (excluding the password hash)
            unset($user['password_hash']);
            echo json_encode([
                "success" => true,
                "message" => "Authentication successful",
                "user" => $user
            ]);
        } else {
            echo json_encode(["success" => false, "message" => "Invalid email or password."]);
        }
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Database error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Missing credentials."]);
}
?>