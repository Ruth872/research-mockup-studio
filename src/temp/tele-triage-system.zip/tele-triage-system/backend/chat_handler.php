<?php
// chat_handler.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once 'connection.php'; // Ensure this uses your $pdo connection

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$data = json_decode(file_get_contents("php://input"), true);
$message = $data['message'] ?? '';
$patient_id = $data['patient_id'] ?? null;

if (empty($message) || !$patient_id) {
    echo json_encode(["success" => false, "message" => "Invalid request data"]);
    exit;
}

try {
    // 1. Fetch Patient Context (Medical History)
    $stmt = $pdo->prepare("SELECT first_name, chronic_conditions, allergies, blood_group FROM patients WHERE patient_id = ?");
    $stmt->execute([$patient_id]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$patient) {
        echo json_encode(["success" => false, "message" => "Patient not found"]);
        exit;
    }

    // 2. Simulated AI Logic 
    // In a production environment, you would send $message + $patient['chronic_conditions'] to an LLM API.
    $name = $patient['first_name'];
    $history = $patient['chronic_conditions'] ?? 'no known chronic conditions';
    
    $ai_feedback = "Hello $name, I have analyzed your query: '$message'. Considering your medical history of $history, I recommend monitoring your symptoms. A clinician has been notified of this session.";
    
    // Simple urgency logic for the Dashboard
    $urgency = (strpos(strtolower($message), 'pain') !== false || strpos(strtolower($message), 'breath') !== false) ? 'High Priority' : 'Routine';

    // 3. Log the interaction for the Clinician Dashboard
    $log = $pdo->prepare("INSERT INTO triage_history (patient_id, user_message, ai_response, urgency_score) VALUES (?, ?, ?, ?)");
    $log->execute([$patient_id, $message, $ai_feedback, $urgency]);

    echo json_encode([
        "success" => true,
        "role" => "assistant",
        "content" => $ai_feedback,
        "urgency" => $urgency
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Backend Error: " . $e->getMessage()]);
}
?>